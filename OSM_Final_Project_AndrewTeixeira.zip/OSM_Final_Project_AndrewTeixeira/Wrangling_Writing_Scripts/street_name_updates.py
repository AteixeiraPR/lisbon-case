#street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)

mapping = { "AV.": "Avienda",
           "avienda" : "Avienda",
            "AV":"Avienda",
            "Av.":"Avienda",
           "Av" : "Avienda",
           "Calcada" : "Calçada",
           "calçada" : "Calçada",
           "E.N.379": "EN",
           "EN9" : "EN",
           "estrada": "Estrada",
           "ESTRADA" : "Estrada",
           "LARGO":"Largo",
           "PARQUE":"Parque",
           "PRAÇA": "Praça",
           "Praca":"Praça",
           'Pàtio':'Pátio',
           "Qt.":"Quinta",
           "Qta.":"Quinta",
           "R":"Rua",
           "R.":"Rua",
           "RUA":"Rua",
           "RUa":"Rua",
           "RUY": "Rua",
           'Rua\u200b':"Rua",
           "rua" : "Rua",
          }


def audit_street_type(street_types, street_name):
    street_type = street_name.split()[0]
    street_types[street_type].add(street_name)


def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")


def audit(osmfile):
    osm_file = open(osmfile, "r")
    street_types = defaultdict(set)
    for event, elem in ET.iterparse(osm_file, events=("start",)):
        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_street_name(tag):
                    audit_street_type(street_types, tag.attrib['v'])
    osm_file.close()

    return street_types


def update_name(name, mapping):
    words = name.split()
    sentence = ""
    for word in words:
        if word in mapping:
            word = mapping[word]
            sentence = sentence + word + " "
        else:
            if word == words[-1]:
                sentence = sentence + word
            else:
                sentence = sentence + word + " "
    return sentence


def street_names_updates():
    st_types = audit(filename)
    #pprint.pprint(dict(st_types))

    for st_type, ways in st_types.iteritems():
        for name in ways:
            better_name = update_name(name, mapping)
            print name, "=>", better_name.title()
