def node_way_contributors(filename):
    contributors = []
    unique_contributors = set()
    file = ET.iterparse(filename)
    for event,elem in file:
        if elem.tag == "node" or elem.tag == "way":
            elem.get('user')
            contributors.append(elem.get('user'))
            unique_contributors.add(elem.get('user'))

    print (len(contributors))
    print (len(unique_contributors))
            
