k_values_set = []
def view_k_values(osmfile):
    k_values = {}
    osm_file = open(osmfile,"r")
    for event, elem in ET.iterparse(osm_file, events =("start",)):
        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                k_value = tag.attrib['k']
                if k_value not in k_values_set:
                    k_values_set.append(k_value)
                    k_values[k_value] = 1
                else:
                    k_values[k_value] +=1
    return k_values

                    
