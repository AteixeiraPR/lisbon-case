#!/usr/bin/env python
#-*- coding: utf-8 -*-
import xml.etree.cElementTree as ET
import pprint
import re
from collections import defaultdict
import csv
import codecs
import re
import xml.etree.cElementTree as ET
import cerberus
import schema

filename = "lisbon_portugal.osm"

#Exploring the data to determine the types of tags and the number of those tags.

def count_tags(filename):
    tag_types = set()
    tag_dict = {}
    file = ET.iterparse(filename)
    for event, elem in file:
        value = elem.tag
        if value not in tag_types:
            tag_types.add(value)
            tag_dict[value] = 1
        elif value in tag_types:
            tag_dict[value] += 1
    return tag_dict
