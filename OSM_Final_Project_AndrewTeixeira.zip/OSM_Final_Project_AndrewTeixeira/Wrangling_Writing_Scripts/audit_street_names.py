def is_street_name(elem):
    return (elem.attrib['k'] == "addr:street")


def audit_street_names(osmfile):
    street_names = {}
    osm_file = open(osmfile, "r")
    for event, elem in ET.iterparse(filename, events=("start",)):
        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if is_street_name(tag):
                    first_word = tag.attrib['v'].split()[0]
                    if first_word not in street_names:
                        street_names[first_word] = 1
                    else:
                        street_names[first_word] += 1
    osm_file.close()

    return street_names
