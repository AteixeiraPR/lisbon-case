QUERY_RELIGION = '''
SELECT ways_tags.key, ways_tags.value, COUNT(ways_tags.value) as total
FROM ways_tags
WHERE ways_tags.key = "religion"
GROUP BY ways_tags.value
ORDER BY total desc
LIMIT 100;
'''
c.execute(QUERY_RELIGION)
data = c.fetchall()
print data
