QUERY_COUNTRY = '''
SELECT union_tags.key, union_tags.value, COUNT(*) as total
FROM (SELECT * FROM nodes_tags UNION ALL SELECT * FROM ways_tags) union_tags
WHERE union_tags.key = "country"
GROUP BY union_tags.value
ORDER BY total desc
LIMIT 100;
'''
c.execute(QUERY_COUNTRY)
data = c.fetchall()
print data
