QUERY = '''
SELECT union_tags.key, union_tags.value, COUNT(*) as count
FROM (SELECT * FROM nodes_tags UNION ALL SELECT * FROM ways_tags) union_tags
WHERE union_tags.key = 'city' or union_tags.key = "ciudad"
GROUP BY union_tags.value
ORDER BY count desc
LIMIT 10;
'''

c.execute(QUERY)
data = c.fetchall()
print data
