QUERY_TOP_USERS = '''
SELECT nodes.user, COUNT(*)
FROM nodes
GROUP BY nodes.user
ORDER BY COUNT(*) DESC
LIMIT 10;
'''

c.execute(QUERY_TOP_USERS)
all_data = c.fetchall()
print(all_data)
