QUERY_TOP_USERS_WAYS = '''
SELECT ways.user, COUNT(*) as total
FROM ways
GROUP BY ways.user
ORDER BY total desc
LIMIT 20;'''

c.execute(QUERY_TOP_USERS_WAYS)
data = c.fetchall()
print data
