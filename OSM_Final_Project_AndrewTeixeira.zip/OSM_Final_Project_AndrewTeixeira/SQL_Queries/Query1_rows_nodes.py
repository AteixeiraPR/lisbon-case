QUERY = '''
SELECT COUNT(*) as rows
FROM nodes'''

c.execute(QUERY)
data = c.fetchall()
print data
