QUERY = '''
SELECT COUNT(*) as rows
FROM ways'''

c.execute(QUERY)
data = c.fetchall()
print data
