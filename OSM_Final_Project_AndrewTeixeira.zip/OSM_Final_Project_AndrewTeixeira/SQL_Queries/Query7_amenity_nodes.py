QUERY_AMENITY = '''
SELECT nodes_tags.key, nodes_tags.value, COUNT (nodes_tags.value) as total
FROM nodes_tags
WHERE nodes_tags.key = "amenity"
GROUP BY nodes_tags.value
ORDER BY total desc
LIMIT 10;'''

c.execute(QUERY_AMENITY)
data = c.fetchall()
print data
