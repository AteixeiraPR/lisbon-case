QUERY_K_MOST_VALUES = '''
SELECT ways_tags.key, COUNT(*) as total
FROM ways_tags
GROUP BY ways_tags.key
ORDER BY total desc
LIMIT 100;
'''
c.execute(QUERY_K_MOST_VALUES)
data = c.fetchall()
print data
