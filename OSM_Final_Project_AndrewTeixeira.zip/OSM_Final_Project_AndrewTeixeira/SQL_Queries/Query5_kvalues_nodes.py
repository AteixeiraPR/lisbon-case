QUERY_K_MOST_VALUES = '''
SELECT nodes_tags.key, COUNT(*) as total
FROM nodes_tags
GROUP BY nodes_tags.key
ORDER BY total desc
LIMIT 100;
'''
c.execute(QUERY_K_MOST_VALUES)
data = c.fetchall()
print data
