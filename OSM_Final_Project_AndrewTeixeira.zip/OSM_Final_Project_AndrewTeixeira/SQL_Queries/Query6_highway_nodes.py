QUERY_HIGHWAY = '''
SELECT nodes_tags.key, nodes_tags.value, COUNT (nodes_tags.value) as total
FROM nodes_tags
WHERE nodes_tags.key = "highway"
GROUP BY nodes_tags.value
ORDER BY total desc
LIMIT 100;'''

c.execute(QUERY_HIGHWAY)
data = c.fetchall()
print data
