QUERY_CUISINE = '''
SELECT nodes_tags.key, nodes_tags.value, COUNT(nodes_tags.value) as total
FROM nodes_tags
WHERE nodes_tags.key = "cuisine"
GROUP BY nodes_tags.value
ORDER BY total desc
LIMIT 10;
'''
c.execute(QUERY_CUISINE)
data = c.fetchall()
print data
